#pragma once

namespace winsockHandling
{
	void init_winsock();
	void close_winsock();
}